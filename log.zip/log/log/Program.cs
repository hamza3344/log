﻿using System;

namespace log
{
    class Program
    {
        static void Main(string[] args)
        {
            double logwithbasee = Math.Log(90);
            Console.WriteLine("With base e " + logwithbasee);
            double logwithanybase = Math.Log(10,3);
            Console.WriteLine("With base 3 " + logwithanybase);
            double logwithbase2 = Math.Log2(1.571);
            Console.WriteLine("With base 2 " + logwithbase2);
            double logwithbase10 = Math.Log10(10);
            Console.WriteLine("With base 10 " + logwithbase10);
        }
    }
}
